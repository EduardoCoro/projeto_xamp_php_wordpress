/*  Theme License    */
/* ------------------------------------ */

## Copyrights for Resources used in this theme.

The theme itself is nothing but 100% GPL v2 or later.

Font 
 ==Awesome 4.0.3
 * License: License - http://fontawesome.io/license (Font: SIL OFL 1.1, CSS: MIT License)
 * Copyright: by @davegandy - http://fontawesome.io - @fontawesome
--------------------------------------------------------------------------------------------

Icon
License: The icons are free for personal use and also free for commercial use.
All icons are under GPL v2 have been created by our team.
Copyright: Mageewp.com, http://www.mageewp.com

Slider images
License: Slider Images are copyrighted and they are the properties of stockvault. 
Copyright: http://www.stockvault.net/terms-of-use, http://www.stockvault.net/

Slideshow
License: This theme uses jQuery Nivo Slider v3.2, which is free to use and abuse under the MIT license.
Copyright: Dev7studios

Administration Panel 
License: For the Administration Panel, we have used "Options Framework", which is under GPL v2 license. 
Copyright: Devin Price

JS files
License: The files owl.carousel.min.js is under MIT license. jquery.nivo.slider.pack.js part of the "Nivo Slider". cubby.js has been created by me and under GPL v2.
Copyright:Bartosz Wojciechowski, Dev7studios, mageewp.com;


	For any help you can mail me at support[at]mageewp.com
	
	
	
== CHANGE LOG == 

= Version 1.1.1 =
* Fixed esc_url issue
* Added title tag support
* Fixed other issues

= Version 1.1.0 =
* Fixed responsive issue
* Font Awesome ready
* Using Bootstrap CSS framework
* Added home page portfolio
* Added contact form

= Version 1.0.8 =
* You can add your own information in the footer now.
* Other features update.