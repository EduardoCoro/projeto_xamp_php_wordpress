

### 1.1.8 - 16/07/2015

 Changes: 


 * Update class-tgm-plugin-activation to latest version
 * Update style.css


### 1.1.7 - 09/04/2015

 Changes: 


 * Fixed Linkedin Link Bug

Linkedin icon was pulling Facebook link instead of the linked in link.
 * Merge pull request #17 from HardeepAsrani/development

Fixed Linkedin Link Bug


### 1.1.5 - 11/12/2014

 Changes: 


 * This fixes #3, #4, #5. Fixed colors change, added date, remove unused featured from customizer + small fixes


### 1.1.2 - 03/12/2014

 Changes: 


 * Update footer.php
 * Update style.css
 * Update style.css


### 1.1 - 17/10/2014

 Changes: 


 * Modified theme tags in style.css and in readme, added link to theme in footer and logo, contact us and about us buttons in theme options
 * Create CHANGELOG
 * Update CHANGELOG
 * Update style.css
 * Changed link in footer
 * changes for wp.org
 * Update style.css

removed a default style which breaks css in a h3 for example
 * Updated theme uri, documentation link and forum link
 * Small fix - first page slider caption
 * Fixed search in firefox and safari
 * Update style.css

Improved how title is display on single post/pages.
 * Sincronized with demo and small improvments
 * fixed wporg feedback   improvements

Changed the website design for consistency and different visual
improvements.
 * updated vers
 * Update style.css
