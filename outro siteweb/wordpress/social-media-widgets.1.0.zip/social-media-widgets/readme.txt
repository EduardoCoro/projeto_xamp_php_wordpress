﻿=== Social Media Widget===
Contributors: Ashirbad Ray
Plugin Name: Social Media Widget
Tags:  sidebar, social, social follow, social following, social links, social media, social media buttons, Social Media Icons, Social Media Widget, social share, social sharing, social widget, Style, time, title, facebook, twitter, google plus, pinterest
Author:Ashirbad Ray
Version: 1.0
License: GPLv2 or later
Donate link: none
Tested up to: 4.3
Requires at least: 4.0.1
Stable Tag: 1.0

==Description==
Easily create beautiful social media link with the install of this plugin.This widget takes a simple, extendable approach for displaying your social media profiles on wordpress website.


= Social Media Widget =

*Social media widget which let's you add icons for Facebook, Twitter, Google+, Pinterest.

This plugin helps you add social Profiles to your wordpress Website .




==Installation==
= Installing the plugin =
1. In your WordPress admin panel, go to *Plugins > New Plugin*, search for **Social Media Widget** and click "*Install now*"
2. Alternatively, download the plugin and upload the contents of `social-media-widget.zip` to your plugins directory, which usually is `/wp-content/plugins/.                                                                                                                                       
3. Activate the plugin.                                                                                                                                 
4. Set social Link Url to the widget.


= Configuring Social Media Widget =
1. Go to *Social media widget  Widget In Apperance->widget -> Sidebar/Footer Widget Section
2.Change the Widget Name For displaying in the website.

== Frequently Asked Questions ==
= Where can I find social Media Widget? =
Go to **Appearance > Widgets** and use the Social Media Widget** widget that comes with the plugin.


= How to display a form in widget areas like the sidebar or footer? =
1.Go to **Appearance > Widgets** and use the Social Media Widget** widget that comes with the plugin.
2. Go to *Social media widget  Widget In Apperance->widget -> Sidebar/Footer Widget Section

== Screenshots ==
1. Social Media Widget Display
1. Social Media Widget setup

== Changelog ==
= 1.0.0 - septmber 11, 2015 =

== Upgrade Notice ==

= Version 1.0 =
* Version 1.0