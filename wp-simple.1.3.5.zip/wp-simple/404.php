<?php
get_header();
get_template_part( 'parts/content', '404');
get_footer();
?>


