<?php
/*
  Template Name: Full Width
 */

get_header();
get_template_part( 'parts/content', 'page_full');
get_footer();
?>