jQuery(document).ready(function(){

    jQuery("#seo_description").charCount({
        allowed: 160 ,		
        warning: 20,
        counterText: 'Recomended Characters Left: '	
    });
    
});