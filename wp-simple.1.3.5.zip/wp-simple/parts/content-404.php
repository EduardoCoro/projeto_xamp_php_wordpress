<div id="page_content_row">
    <div class="container">
        <div class="row">
            <div class="col-md-8 editable">
                <div>
                    <h2>The content you are looking for is not available</h2>
                </div>
            </div>
            <?php
            get_sidebar();
            ?>
        </div>
    </div>
</div>

