<div class="visible-lg">
<p style="text-align:center; margin-top:10px;"><span style="color:#ffffff; text-shadow: 1px 1px 0px #000000; filter: dropshadow(color=#000000, offx=1, offy=1); font-style:normal;  font-size:80px; font-weight:bold; line-height:1.1em;">A RESPONSIVE THEME  <br>FOR WORDPRESS</span></p>
</div>
<div class="visible-lg">
<p style="text-align:center;"><span style="color:#ffffff; text-shadow: 1px 1px 0px #000000; filter: dropshadow(color=#000000, offx=1, offy=1); font-style:italic; font-size:22px; font-weight:normal; line-height:1.1em;">Customize layout, fonts, slideshows, banners, sidebars <br>and more with just the click of a button!</span></p>
</div>

<div class="visible-md">
<p style="text-align:center; margin-top:10px;"><span class="nimbus_typography_one" style="color:#ffffff; text-shadow: 1px 1px 0px #000000; filter: dropshadow(color=#000000, offx=1, offy=1); font-style:normal;  font-size:70px; font-weight:bold; line-height:1.1em;">A RESPONSIVE THEME  <br>FOR WORDPRESS</span></p>
</div>
<div class="visible-md">
<p style="text-align:center;"><span class="" style="color:#ffffff; text-shadow: 1px 1px 0px #000000; filter: dropshadow(color=#000000, offx=1, offy=1); font-style:italic; font-size:20px; font-weight:normal; line-height:1.1em;">Customize layout, fonts, slideshows, banners, sidebars <br>and more with just the click of a button!</span></p>
</div>

<div class="visible-sm">
<p style="text-align:center;"><span class="" style="color:#ffffff; text-shadow: 1px 1px 0px #000000; filter: dropshadow(color=#000000, offx=1, offy=1); font-style:normal;  font-size:48px; font-weight:bold; line-height:1.1em;">A RESPONSIVE THEME  <br>FOR WORDPRESS</span></p>
</div>

<div class="visible-xs">
<p style="text-align:center;"><span class="" style="color:#ffffff; text-shadow: 1px 1px 0px #000000; filter: dropshadow(color=#000000, offx=1, offy=1); font-style:normal;  font-size:40px; font-weight:bold; line-height:1.1em;">A RESPONSIVE THEME  <br>FOR WORDPRESS</span></p>
</div>

