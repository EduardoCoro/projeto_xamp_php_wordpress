<div id="post-example" class="blog_small_wrap">
    <?php
    get_template_part( 'parts/image', '105_90');
    ?>
    <h3><a href="#"><?php _e('Example Post', 'nimbus'); ?></a></h3>
    <p class="blog_meta">By <a href="#" title="Posts by Author" rel="author">Author</a> on October 3, 2013</p>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
</div>