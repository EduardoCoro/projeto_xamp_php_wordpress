<?php
get_header();
get_template_part( 'parts/content', 'blog');
get_footer();
?>