<?php
/*
  Template Name: Sitemap
 */

get_header();
get_template_part( 'parts/content', 'sitemap');
get_footer();
?>